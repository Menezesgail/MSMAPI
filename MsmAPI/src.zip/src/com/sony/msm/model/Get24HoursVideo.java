package com.sony.msm.model;


	
	import java.util.List;

	public class Get24HoursVideo {

	private List<Content> get24HoursVideos;

	public List<Content> getGet24HoursVideos() {
	return get24HoursVideos;
	}

	public void setGet24HoursVideos(List<Content> get24HoursVideos) {
	this.get24HoursVideos = get24HoursVideos;
	}


	}


