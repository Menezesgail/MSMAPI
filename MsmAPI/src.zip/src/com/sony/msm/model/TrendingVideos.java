package com.sony.msm.model;

import java.util.List;

public class TrendingVideos {

	private List<Content> getTrendingVideos;

	public List<Content> getGetTrendingVideos() {
		return getTrendingVideos;
	}

	public void setGetTrendingVideos(List<Content> getTrendingVideos) {
		this.getTrendingVideos = getTrendingVideos;
	}



	

		

		
	

}
