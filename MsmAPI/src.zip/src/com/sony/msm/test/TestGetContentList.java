package com.sony.msm.test;

import mockit.Expectations;
import mockit.Mocked;

import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.sony.msm.impl.TrendingVideo;
import com.sony.msm.model.Content;

import org.testng.asserts.*;

public class TestGetContentList {	
	@Mocked 
	TrendingVideo trendingVideo = new TrendingVideo();

	@Test
	public void testGetTrendingVideo() throws JsonParseException, JsonMappingException, Exception {
		List<Content> list = trendingVideo.getData();
		Assert.assertNotNull(list);


		new Expectations(){{

		   EntityUtils.toString((HttpEntity)any);
			returns(readFromFile());


		}};

	}

	public String readFromFile(){
		BufferedReader br = null;
		String readString="";
		try {

			String sCurrentLine;
			br = new BufferedReader(new FileReader("C:\\getTrendingVideos_json.txt"));

			while ((sCurrentLine = br.readLine()) != null) {
				readString+=sCurrentLine;
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return readString; 
	}



}
